from django.apps import AppConfig


class FamilyloginConfig(AppConfig):
    name = 'FamilyLogin'
